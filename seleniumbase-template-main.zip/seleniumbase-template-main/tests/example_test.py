""" example_test.py """
from seleniumbase import BaseCase
import os
import sys
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from conftest import config
from pages.homepage import HomePage

class MyTestClass(BaseCase):
    
   def setUp(self):
        super(MyTestClass, self).setUp()
        self.driver.maximize_window()
        self.open(config[os.getenv('env')]['url'])
        

   def test_navigate_to_academy_page(self):
        HomePage.click_academy_link(self)
        self.assert_equal("Tech Academy | Ten10",self.get_page_title())

   def test_navigate_to_contact_page(self):
        HomePage.click_contact_link(self)
        self.assert_equal("Contact | Ten10", self.get_page_title())

   def test_failing(self):
        HomePage.click_contact_link(self)
        self.assert_equal("The Application Process | Apply Today",self.get_page_title())
   