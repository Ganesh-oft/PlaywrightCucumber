import os

config = {
    'dev': {
        'url': 'https://ten10.com'
    },
    'test': {
        'url': 'https://ten10.com'
    }
}

def pytest_addoption(parser):
    parser.addoption("--environment", action="store", default="dev")


def pytest_configure(config):
        os.environ["env"] = config.getoption('environment')
