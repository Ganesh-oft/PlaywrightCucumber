seleniumbase install chromedriver
seleniumbase install geckodriver

pytest tests/ --html=report.html -n 3 