class HomePage:
    ACADEMY_LINK = "#menu-item-476 > a"
    CONTACT_LINK = "#menu-item-4956 > a"

    def click_academy_link(self):
        HomePage.click_link(self, HomePage.ACADEMY_LINK)

    def click_contact_link(self):
        HomePage.click_link(self, HomePage.CONTACT_LINK)

    def click_link(self, link):
        self.click(link)
        self.wait_for_element_absent(".home")
