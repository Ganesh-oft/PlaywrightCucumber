/**
 * Static Test Configuration class to help better use the .env file variables in your tests
 * Allows for autocompletion and typing of environment variables
 * This isn't mandatory, but can definitely help make writing tests easier - you can even have some logic in here to give these configs individual types for better use in your code
 * In this example you'll see each config variable is of type string, whereas process.env.ENVIRONMENT for example has type string | undefined
 */
export abstract class TestConfig {
  static readonly environment = process.env.ENVIRONMENT ?? '';

  static readonly urls = {
    ui: {
      loginUrl: process.env.LOGIN_URL ?? ''
    },
    api: {
      apiGatewayUrl: process.env.API_GATEWAY_URL ?? undefined, // Not configured for the example tests
      bookingServiceUrl: process.env.BOOKING_SERVICE_BASE_URL ?? ''
    }
  };

  static readonly credentials = {
    ui: {
      username: process.env.LOGIN_USERNAME ?? '',
      password: process.env.LOGIN_PASSWORD ?? ''
    },
    api: {
      username: process.env.API_USERNAME ?? '',
      password: process.env.API_PASSWORD ?? ''
    }
  };
}
