// For more info on fixtures - see https://playwright.dev/docs/test-fixtures
// This is a complex topic for new automation engineers - the patterns below are reusable to help the creation of more fixtures without needing too much in-depth knowledge

// Importing test as base here allows us to export our own "test" variable later, giving us more natural access to the Playwright API
// You can see this as us simply aliasing the Playwright version of "test", just so we can still instantiate our tests with the standard test('Test Name', () => ...) syntax later
import { test as base } from '@playwright/test';
import { LoginPage } from '../pages/login.page';
import { HomePage } from '../pages/home.page';
import { BookingService } from '../services/booking-service';

// Separate out your fixtures into their own types for neater grouping, then union them into the TestFixtures type
type UIFixtures = {
  loginPage: LoginPage;
  homePage: HomePage;
};

type APIFixtures = {
  bookingService: BookingService;
};

type TestFixtures = UIFixtures & APIFixtures;

type WorkerFixtures = {
  workerScopedFixture: void;
};

export const test = base.extend<TestFixtures, WorkerFixtures>({
  // UI Fixtures
  // These should be simple but repeated actions that produce some state we can inject into our tests
  // For the loginPage fixture, we get a loginPage object allowing us to never need to directly navigate to the page - not a massive time save, but we only need to change this code (or the Page Object) in case of a change in workflow
  loginPage: async ({ page }, use) => {
    // Think of anything before the "await use()" line as a test.beforeEach, and anything after it as a test.afterEach!
    const loginPage = new LoginPage(page);
    await loginPage.navigateTo();
    await use(loginPage);
    // You can add any teardown process here - we don't need anything for these fixtures
  },
  // For the homePage fixture, we get a logged in homePage object, basically meaning we don't have to worry about the login form for any tests that don't explicitly test it
  // As you layer these fixtures up, you can even have state added and torn down as part of the fixture itself, giving your tests more isolation and improving parallelism options
  homePage: async ({ page, loginPage }, use) => {
    await loginPage.signIn();
    await use(new HomePage(page));
  },
  // API Fixtures
  // It's not just the UI that we can "Page Object"-ify, we can use fixtures to give us our own internal class for the API that we are testing, meaning we get much more control over what a given test has access to
  bookingService: async ({ request }, use) => {
    await use(new BookingService(request));
  }
  /**
   * Worker Scoped Fixtures - Equivalent to a beforeAll
   * You can see an example below
   */
  // workerScopedFixture: [
  //   async ({}, use) => {
  //     await use();
  //   },
  //   { scope: 'worker' }
  // ]
});

// Export this here so we only need to reference this file for both test and expect (saves us having two import statements!)
// Later down the line, you can create custom assertions here - see https://playwright.dev/docs/test-assertions#add-custom-matchers-using-expectextend
export { expect } from '@playwright/test';
