/**
 * At Present this file isn't used for anything but if there's some abstractable functionality of your framework you can include it here
 * You can either use an abstract class for this, or simply export functions at the top level
 */
