# Playwright Typescript Accelerator Template

An automation accelerator template, designed as a documented tool to be forked to jump-start a new automation framework

## Pre-requisites

This project uses the Node JS / Typescript bindings for Playwright, and so requires that you have Node JS installed on your machine.
Get the latest version here: https://nodejs.org/en

You will also need to use your preferred Typescript IDE, my suggestion would be a well-configured VSCode.

It is highly recommended if using VSCode you install the following extensions:

- Playwright Test for VSCode
- Prettier - Code formatter
- ESLint
- DotENV

Further utility extension recommendations:

- indent-rainbow
- Rainbow CSV
- vscode-icons
- Todo Tree

# Installation

Clone this repository, and run the following commands at the root of the project:

- `npm install`, to install all the necessary node modules
- `npx playwright install`, to install the playwright browsers

# Usage

At a high level, you can run `npx playwright test` to execute all tests in the framework, but to be more selective see the official playwright documentation for the CLI: https://playwright.dev/docs/test-cli

Alternatively, there are a few scripts defined in the `package.json` file, one for each project, which can be run as follows:

- `npm run test`, an alias for `npx playwright test` to run all tests across the framework
- `npm run test:api`, an alias for `npx playwright test --project=API` to run all the tests in the API project
- `npm run test:ui:chrome`, an alias for `npx playwright test --project="UI - Chromium"` to run all the tests in the UI tests with the Chromium browser
- `npm run test:ui:firefox`, similar to the chrome option, run all the tests in the UI tests with the Firefox browser
- `npm run test:ui:safari`, similar to the chrome option, run all the tests in the UI tests with the Webkit browser

If using VSCode and the Playwright Test for VSCode extension, you can also run tests from the code itself, allowing for more granular testing and debugging options.
