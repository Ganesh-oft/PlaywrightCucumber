// Note the import now comes from our fixtures file rather than Playwright!
import { test, expect } from '../../../framework/fixtures';
import { HomePage } from '../../../pages/home.page';

// Wrapping your tests into test.describes allows for more clean structuring of your tests
// It can be helpful to have one main test.describe block per file - however this isn't a hard and fast rule
// Tip: Use tags (using the pattern below @tag-name) to allow for better test run configuration
test.describe('Feature: Accelerator UI Example Tests:', { tag: ['@Accelerator', '@Example-Tests', '@UI'] }, () => {
  // You can see how we've taken the loginPage as a fixture, and we can instantly use it - however we do need the 'page' fixture as well to build out our future pages
  test('An example test to show how to interact with the page objects', async ({ loginPage, page }) => {
    await loginPage.signIn();
    expect(await new HomePage(page).isLoaded()).toBe(true);
  });

  // Here, we've skipped the need for a loginPage object, as it's already handled by the homePage fixture, which will complete a login for us
  test('An example test to show how we can use page objects and fixtures together', async ({ homePage }) => {
    expect(await homePage.isLoaded()).toBe(true);
  });
});
