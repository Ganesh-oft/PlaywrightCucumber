import { Locator, Page } from '@playwright/test';
import { expect } from '../framework/fixtures';

/**
 * An example Page Object, representing a very basic Home Page
 * This page is a follow on from the LoginPage operating against the following: https://www.saucedemo.com/v1/inventory.html
 */
export class HomePage {
  // Use private and readonly for locators where possible/reasonable and other member variables
  // This helps us to keep our tests maintainable - if a locator changes, but the flow remains the same, we only need to change the locator and it should bubble up to the test naturally
  private readonly productPageHeading: Locator;

  // Note the Typescript constructor pattern - we don't need to define the page member variable outside the constructor and we just skip a couple of lines of code
  constructor(private readonly page: Page) {
    // Prioritise user-facing attributes for locators, getByRole is probably the best option as it has a lot of controls and Aria roles hold quite a lot of semantic meaning for how something should be used
    // As of Playwright 1.53, we have the option to add a description of locators and actions, it's a nice QOL (Quality of Life) change but is not mandatory.
    this.productPageHeading = this.page.getByText('Products').describe('Product Page Heading');
  }

  async isLoaded(): Promise<boolean> {
    // Using this expect here means if the page doesn't load, our test will fail
    await expect(this.productPageHeading).toBeVisible();
    // Alternatively, we can use this line if we want to avoid having expects in our page objects
    // This is a non-retrying check, so if you want to use it, it can be worth creating a helper that handles retries
    // The advantage here is that the test will not immediately fail if the page doesn't load when this function is called, and we have the option to assert on it in our test
    // await this.productPageHeading.waitFor({ state: 'visible' }).catch(() => {
    //   return false;
    // });
    return true;
  }
}
