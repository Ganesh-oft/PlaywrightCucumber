import { Locator, Page } from '@playwright/test';
import { TestConfig } from '../framework/config';
import { test } from '../framework/fixtures';

/**
 * An example Page Object, representing a very basic Login Page
 * Note that you should avoid using expect inside your Page Objects
 *
 * This is testing against the following page: https://www.saucedemo.com/v1/ for demo purposes only
 */
export class LoginPage {
  // Use private and readonly for locators and other member variables
  // This means you wont be able to directly reference them in your tests, but we secure a clean API for interacting with the page itself
  private readonly url: string = TestConfig.urls.ui.loginUrl;

  private readonly usernameInput: Locator;
  private readonly passwordInput: Locator;
  private readonly loginButton: Locator;

  // Note the Typescript constructor pattern - we don't need to define the page member variable outside the constructor and we just skip a couple of lines of code
  constructor(private readonly page: Page) {
    // Prioritise user-facing attributes for locators
    // See the home.page.ts file for more info on the locator.describe() part here!
    this.usernameInput = this.page.getByRole('textbox', { name: 'username' }).describe('Username Input');
    this.passwordInput = this.page.getByRole('textbox', { name: 'password' }).describe('Password Input');
    this.loginButton = this.page.getByRole('button', { name: 'Login' }).describe('Login Button');
  }

  // Wrap all your locators with functions that represent the user behaviour around these locators
  async navigateTo(): Promise<void> {
    await this.page.goto(this.url);
  }

  async enterUsername(username?: string): Promise<void> {
    await this.usernameInput.fill(username ?? TestConfig.credentials.ui.username);
  }

  async enterPassword(password?: string): Promise<void> {
    await this.passwordInput.fill(password ?? TestConfig.credentials.ui.password);
  }

  async clickLoginButton(): Promise<void> {
    await this.loginButton.click();
  }

  // Group logical functionality together to make testing more reliable and reduce duplication
  // Optionally, use test.step to give the reports more context of the action being performed
  async signIn(username?: string, password?: string) {
    test.step(`Login as ${username}`, async () => {
      await this.enterUsername(username);
      await this.enterPassword(password);
      await this.clickLoginButton();
    });
  }
}
