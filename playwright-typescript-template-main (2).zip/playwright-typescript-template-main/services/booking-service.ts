import { APIRequestContext, APIResponse } from '@playwright/test';
import { TestConfig } from '../framework/config';

/**
 * An example API Service, representing a service for creating and maintaining a list of bookings
 * This sample uses: https://restful-booker.herokuapp.com/apidoc/index.html
 */
export class BookingService {
  // Typically as part of functional tests you'll be coming in through the API gateway, which should be configured at the project level in the playwright.config.ts file
  // But sometimes you'll find yourself needing to go direct to service (particularly if we need to hit internal services) so it can be useful to have these urls here
  // Remember to pull as much from the config as possible to avoid hard coding
  private readonly baseUrl: string = TestConfig.urls.api.apiGatewayUrl ?? TestConfig.urls.api.bookingServiceUrl;

  private readonly auth: string = `${this.baseUrl}/auth`;
  private readonly booking: string = `${this.baseUrl}/booking`;
  private readonly handleBooking = (bookingId: string) => `${this.booking}/${bookingId}`;
  private readonly healthcheck = `${this.baseUrl}/ping`;

  // Similarly to the page objects, we're going to wrap our API calls, so we need to have access to an APIRequestContext object here
  constructor(private readonly request: APIRequestContext) {}

  // Because we're returning a Promise<APIResponse> here, we can write our functions in a 'traditional' style or an arrow function style - this is completely personal preference as they fundamentally do the same things
  // Whichever you choose of the two formats below, the main thing is to stay consistent!
  async getBookingIds(): Promise<APIResponse> {
    return await this.request.get(this.booking);
  }

  // TODO: Normally you'll authenticate slightly differently - I'll aim to update this later
  // To break down: Normally you'll try to engage authentication at the project level (using project dependencies) or at the fixture level, using a custom fixture
  // For ease of this accelerator, this should work well for very simple authentication (albeit quite a bit of duplication)
  public addBooking = async (requestBody: Record<string, unknown>, token: string): Promise<APIResponse> => await this.request.post(this.booking, { headers: { token: token }, data: requestBody });

  public getBooking = async (bookingId: string, token: string): Promise<APIResponse> => await this.request.get(this.handleBooking(bookingId), { headers: { token: token } });

  public updateBooking = async (bookingId: string, requestBody: Record<string, unknown>, token: string): Promise<APIResponse> =>
    await this.request.patch(this.handleBooking(bookingId), { headers: { token: token }, data: requestBody });

  public deleteBooking = async (bookingId: string, token: string): Promise<APIResponse> => await this.request.delete(this.handleBooking(bookingId), { headers: { token: token } });

  public ping = async (token: string): Promise<APIResponse> => await this.request.get(this.healthcheck, { headers: { token: token } });

  public authenticate = async (requestBody: Record<string, unknown>): Promise<APIResponse> => await this.request.post(this.auth, { data: requestBody });
}
